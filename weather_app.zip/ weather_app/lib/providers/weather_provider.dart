import 'package:flutter/material.dart';
import '../models/weather.dart';
import '../services/weather_service.dart';

class WeatherProvider with ChangeNotifier {
  final WeatherService _weatherService = WeatherService();
  Weather? _currentWeather;

  Weather? get currentWeather => _currentWeather;

  Future<void> fetchWeather(String city) async {
    try {
      final weather = await _weatherService.getWeather(city);
      _currentWeather = weather;
      notifyListeners();
    } catch (error) {
      throw Exception('Failed to fetch weather: $error');
    }
  }
}
