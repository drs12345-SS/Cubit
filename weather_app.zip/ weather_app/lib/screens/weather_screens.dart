import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/weather_provider.dart';

class WeatherScreen extends StatelessWidget {
  final TextEditingController _cityController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Weather App'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: _cityController,
              decoration: const InputDecoration(labelText: 'Enter city'),
            ),
            const SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                final city = _cityController.text;
                context.read<WeatherProvider>().fetchWeather(city);
              },
              child: const Text('Get Weather'),
            ),
            const SizedBox(height: 16.0),
            Consumer<WeatherProvider>(
              builder: (context, weatherProvider, _) {
                final weather = weatherProvider.currentWeather;
                if (weather != null) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Location: ${weather.location}'),
                      Text('Temperature: ${weather.temperature.toStringAsFixed(2)}°C'),
                      Text('Description: ${weather.description}'),
                    ],
                  );
                } else {
                  return const Text('No weather data available');
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}
