package com.example.cubit_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
